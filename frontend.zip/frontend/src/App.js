import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_BASE = 'http://localhost:8000';

// Icons as simple SVG components
const SearchIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="11" cy="11" r="8" />
    <line x1="21" y1="21" x2="16.65" y2="16.65" />
  </svg>
);

const SparklesIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5L12 3z" />
    <path d="M19 15l1 3 3 1-3 1-1 3-1-3-3-1 3-1 1-3z" />
  </svg>
);

const FileTextIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <polyline points="14 2 14 8 20 8" />
    <line x1="16" y1="13" x2="8" y2="13" />
    <line x1="16" y1="17" x2="8" y2="17" />
  </svg>
);

const ClockIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <circle cx="12" cy="12" r="10" />
    <polyline points="12 6 12 12 16 14" />
  </svg>
);

const UserIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </svg>
);

const CalendarIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
    <line x1="16" y1="2" x2="16" y2="6" />
    <line x1="8" y1="2" x2="8" y2="6" />
    <line x1="3" y1="10" x2="21" y2="10" />
  </svg>
);

const DatabaseIcon = () => (
  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <ellipse cx="12" cy="5" rx="9" ry="3" />
    <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
    <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
  </svg>
);

const BrainIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 4.5a2.5 2.5 0 0 0-4.96-.46 2.5 2.5 0 0 0-1.98 3 2.5 2.5 0 0 0 .47 4.43A2.5 2.5 0 0 0 7.5 14.5a2.5 2.5 0 0 0 3.46 2.32A2.5 2.5 0 0 0 12 19.5" />
    <path d="M12 4.5a2.5 2.5 0 0 1 4.96-.46 2.5 2.5 0 0 1 1.98 3 2.5 2.5 0 0 1-.47 4.43 2.5 2.5 0 0 1-1.97 2.53 2.5 2.5 0 0 1-3.46 2.32A2.5 2.5 0 0 1 12 19.5" />
    <path d="M12 4.5v15" />
  </svg>
);

const TrendingIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
    <polyline points="17 6 23 6 23 12" />
  </svg>
);

const LinkIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
  </svg>
);

function App() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({ papers_count: 0, chunks_count: 0, status: 'loading' });
  const [activeTab, setActiveTab] = useState('synthesis');
  const [citations, setCitations] = useState(null);
  const [searchHistory, setSearchHistory] = useState([]);

  const exampleQueries = [
    "What are the main criticisms of BERT?",
    "Find papers proposing alternatives to attention",
    "What datasets are commonly used in NLP?",
    "How do transformers handle long sequences?",
    "Machine learning for medical diagnosis"
  ];

  // Fetch stats on mount
  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await axios.get(`${API_BASE}/api/stats`);
      setStats(response.data);
    } catch (err) {
      console.error('Failed to fetch stats:', err);
      setStats({ papers_count: 0, chunks_count: 0, status: 'error' });
    }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    setResults(null);

    try {
      const response = await axios.post(`${API_BASE}/api/search`, {
        query: query,
        n_results: 20,
        include_synthesis: true
      });
      setResults(response.data);
      setActiveTab('synthesis');
      
      // Add to search history
      if (!searchHistory.includes(query)) {
        setSearchHistory(prev => [query, ...prev].slice(0, 5));
      }
    } catch (err) {
      console.error('Search error:', err);
      setError(err.response?.data?.detail || 'Search failed. Please ensure the backend is running.');
    } finally {
      setLoading(false);
    }
  };

  const handleExampleClick = (exampleQuery) => {
    setQuery(exampleQuery);
  };

  const fetchCitations = async () => {
    if (citations) return;
    
    try {
      const response = await axios.get(`${API_BASE}/api/citations`);
      setCitations(response.data);
    } catch (err) {
      console.error('Citation fetch error:', err);
    }
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    if (tab === 'citations') {
      fetchCitations();
    }
  };

  // Format synthesis text with better styling
  const formatSynthesis = (text) => {
    if (!text) return null;
    
    // Split by lines and format
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      // Headers
      if (line.startsWith('##')) {
        return <h3 key={idx} className="synthesis-header">{line.replace(/^#+\s*/, '')}</h3>;
      }
      // Bullet points
      if (line.trim().startsWith('•') || line.trim().startsWith('-') || line.trim().startsWith('*')) {
        return <li key={idx} className="synthesis-bullet">{line.replace(/^[\s•\-*]+/, '')}</li>;
      }
      // Numbered items
      if (/^\d+\./.test(line.trim())) {
        return <li key={idx} className="synthesis-numbered">{line.replace(/^\d+\.\s*/, '')}</li>;
      }
      // Empty lines
      if (!line.trim()) {
        return <br key={idx} />;
      }
      // Regular paragraphs
      return <p key={idx} className="synthesis-para">{line}</p>;
    });
  };

  return (
    <div className="app-container">
      {/* Header */}
      <header className="header">
        <div className="logo-section">
          <BrainIcon />
          <h1>Intelligent Document Search</h1>
        </div>
        <p className="tagline">AI-Powered Research Paper Analysis with Cross-Document Synthesis</p>
      </header>

      {/* Stats Banner */}
      <div className="stats-banner">
        <div className="stat-item">
          <div className="stat-icon">
            <FileTextIcon />
          </div>
          <div className="stat-content">
            <div className="stat-value">{stats.papers_count.toLocaleString()}</div>
            <div className="stat-label">Papers Indexed</div>
          </div>
        </div>
        <div className="stat-item">
          <div className="stat-icon">
            <DatabaseIcon />
          </div>
          <div className="stat-content">
            <div className="stat-value">{stats.chunks_count.toLocaleString()}</div>
            <div className="stat-label">Searchable Chunks</div>
          </div>
        </div>
        <div className="stat-item">
          <div className="stat-icon">
            <TrendingIcon />
          </div>
          <div className="stat-content">
            <div className="stat-value" style={{ color: stats.status === 'ready' ? '#4ade80' : '#fbbf24' }}>
              {stats.status === 'ready' ? 'Online' : stats.status === 'loading' ? 'Loading...' : 'Offline'}
            </div>
            <div className="stat-label">System Status</div>
          </div>
        </div>
      </div>

      {/* Search Section */}
      <section className="search-section">
        <form onSubmit={handleSearch} className="search-box">
          <div className="search-input-wrapper">
            <SearchIcon />
            <input
              type="text"
              className="search-input"
              placeholder="Ask a research question... (e.g., 'What are the main criticisms of BERT?')"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <button type="submit" className="search-button" disabled={loading || !query.trim()}>
            {loading ? (
              <>
                <div className="button-spinner"></div>
                Analyzing...
              </>
            ) : (
              <>
                <SparklesIcon />
                Search & Synthesize
              </>
            )}
          </button>
        </form>

        {/* Example Queries */}
        <div className="example-section">
          <span className="example-label">Try:</span>
          <div className="example-queries">
            {exampleQueries.map((eq, idx) => (
              <button
                key={idx}
                className="example-query"
                onClick={() => handleExampleClick(eq)}
              >
                {eq}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Loading State */}
      {loading && (
        <div className="loading">
          <div className="loading-content">
            <div className="spinner"></div>
            <h3>Analyzing Research Papers...</h3>
            <p>Searching through {stats.papers_count.toLocaleString()} papers and generating AI synthesis</p>
            <div className="loading-steps">
              <div className="loading-step active">Semantic Search</div>
              <div className="loading-step">Finding Relevant Papers</div>
              <div className="loading-step">Cross-Document Analysis</div>
              <div className="loading-step">Generating Synthesis</div>
            </div>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="error-message">
          <h3>Error</h3>
          <p>{error}</p>
          <button onClick={() => setError(null)} className="dismiss-button">Dismiss</button>
        </div>
      )}

      {/* Results Section */}
      {results && !loading && (
        <section className="results-section">
          {/* Results Header */}
          <div className="results-header">
            <div className="results-title">
              <h2>Results for "{results.query}"</h2>
              <div className="results-meta">
                <span className="meta-item">
                  <FileTextIcon />
                  {results.papers_analyzed} papers analyzed
                </span>
                <span className="meta-item">
                  <ClockIcon />
                  {results.response_time_ms}ms response time
                </span>
                <span className="meta-item success">
                  <TrendingIcon />
                  {results.total_chunks_searched} chunks searched
                </span>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="tabs">
            <button
              className={`tab ${activeTab === 'synthesis' ? 'active' : ''}`}
              onClick={() => handleTabChange('synthesis')}
            >
              <SparklesIcon />
              AI Synthesis
            </button>
            <button
              className={`tab ${activeTab === 'papers' ? 'active' : ''}`}
              onClick={() => handleTabChange('papers')}
            >
              <FileTextIcon />
              Papers ({results.papers?.length || 0})
            </button>
            <button
              className={`tab ${activeTab === 'citations' ? 'active' : ''}`}
              onClick={() => handleTabChange('citations')}
            >
              <LinkIcon />
              Citation Analysis
            </button>
          </div>

          {/* Synthesis Tab */}
          {activeTab === 'synthesis' && results.synthesis && (
            <div className="synthesis-card">
              <div className="synthesis-header-row">
                <h2>
                  <SparklesIcon />
                  AI-Powered Cross-Document Synthesis
                </h2>
                <span className="ai-badge">GPT-Powered</span>
              </div>
              <div className="synthesis-content">
                {formatSynthesis(results.synthesis)}
              </div>
              {results.note && (
                <div className="synthesis-note">
                  <span>Note:</span> {results.note}
                </div>
              )}
              <div className="synthesis-footer">
                <span>Based on analysis of {results.papers_analyzed} research papers</span>
              </div>
            </div>
          )}

          {/* Papers Tab */}
          {activeTab === 'papers' && (
            <div className="papers-grid">
              {results.papers?.map((paper, idx) => (
                <div key={idx} className="paper-card">
                  <div className="paper-rank">#{idx + 1}</div>
                  <div className="paper-content">
                    <div className="paper-title">{paper.title || 'Untitled Paper'}</div>
                    <div className="paper-meta">
                      {paper.authors && (
                        <span className="meta-tag">
                          <UserIcon />
                          {paper.authors.length > 40 ? paper.authors.substring(0, 40) + '...' : paper.authors}
                        </span>
                      )}
                      {paper.year && (
                        <span className="meta-tag">
                          <CalendarIcon />
                          {paper.year}
                        </span>
                      )}
                    </div>
                    <div className="paper-score">
                      <div className="score-bar">
                        <div 
                          className="score-fill" 
                          style={{ width: `${paper.relevance_score * 100}%` }}
                        ></div>
                      </div>
                      <span className="score-text">{(paper.relevance_score * 100).toFixed(1)}% relevant</span>
                    </div>
                    {paper.snippets && paper.snippets[0] && (
                      <div className="paper-snippet">
                        "{paper.snippets[0]}..."
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Citations Tab */}
          {activeTab === 'citations' && (
            <div className="citation-section">
              {!citations ? (
                <div className="loading">
                  <div className="spinner"></div>
                  <p>Loading citation analysis...</p>
                </div>
              ) : (
                <>
                  <div className="citation-card">
                    <h3><TrendingIcon /> Most Cited Papers in Corpus</h3>
                    <ul className="citation-list">
                      {citations.most_cited?.slice(0, 10).map((paper, idx) => (
                        <li key={idx}>
                          <span className="citation-rank">#{idx + 1}</span>
                          <span className="citation-title">{paper.title || `Paper ${paper.id}`}</span>
                          <span className="citation-count">
                            {paper.citation_count} citations
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="citation-card">
                    <h3><DatabaseIcon /> Citation Distribution</h3>
                    <div className="distribution-chart">
                      {Object.entries(citations.citation_distribution || {}).map(([range, count]) => {
                        const maxCount = Math.max(...Object.values(citations.citation_distribution || {}));
                        const height = maxCount > 0 ? (count / maxCount) * 100 : 0;
                        return (
                          <div key={range} className="distribution-bar">
                            <div
                              className="bar-fill"
                              style={{ height: `${Math.max(height, 5)}%` }}
                            ></div>
                            <div className="bar-value">{count.toLocaleString()}</div>
                            <div className="bar-label">{range}</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="citation-stats">
                    <div className="citation-stat">
                      <span className="stat-number">{citations.total_papers?.toLocaleString()}</span>
                      <span className="stat-desc">Total Papers</span>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </section>
      )}

      {/* Empty State */}
      {!results && !loading && !error && (
        <div className="empty-state">
          <div className="empty-state-icon">
            <DatabaseIcon />
          </div>
          <h3>Ready to Explore Research</h3>
          <p>Enter a research question above to search across {stats.papers_count.toLocaleString()} papers with AI-powered synthesis</p>
          <div className="features-grid">
            <div className="feature-item">
              <SearchIcon />
              <span>Semantic Search</span>
            </div>
            <div className="feature-item">
              <SparklesIcon />
              <span>AI Synthesis</span>
            </div>
            <div className="feature-item">
              <LinkIcon />
              <span>Citation Analysis</span>
            </div>
            <div className="feature-item">
              <ClockIcon />
              <span>Fast Results</span>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="footer">
        <p>Intelligent Document Search System | Built for Hackathon 2024</p>
        <p className="tech-stack">FastAPI + React + ChromaDB + OpenAI GPT</p>
      </footer>
    </div>
  );
}

export default App;
